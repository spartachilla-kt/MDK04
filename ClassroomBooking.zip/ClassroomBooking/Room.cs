﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassroomBooking.Models
{
    public class Room
    {
        public int Id { get; set; }
        public string Number { get; set; } = "";
        public string ComputerCount { get; set; }
        public string IsAvailable { get; set; }
    }
}